import java.util.Arrays;
import java.ArrayList;

public class NumberProcessing{
    public static void main(String[] args) {
        int[] numbers = {116, 88, 20, 90, 30, 77, 54, 31};
        int[] sortedNumbers = numbers.clone();
        Arrays.sort(sortedNumbers);
        System.out.println("case 1 =");
        for (int i = 0; i < sortedNumbers.length; i++){
            System.out.print(sortedNumbers[i]);
            if ((i< sortedNumbers.length - 1)) {
                System.out.println(" , ");
            }
        }
        System.out.println("// mengurutkan dari angka terkecil ke terbesar");
        java.util.ArrayList <Integer> multiplese0f6 = new java.util.ArrayList<>();
        for (int num : numbers){
            if (num % 6 == 0){
                multiplese0f6.add(num);
            }
        }
        System.out.println("case 2 =");
        for (int i = 0; i < multiplese0f6.size(); i++){
            System.out.println(multiplese0f6.get(i));
            if (i< multiplese0f6.size()- 1){
                System.out.println(", ");
            }
        }
        System.out.println("//mencetak angka yang merupakan kelipatan angka 6");
    }
}